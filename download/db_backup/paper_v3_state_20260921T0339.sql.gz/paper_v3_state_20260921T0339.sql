BEGIN TRANSACTION;
CREATE TABLE accruals(
      acc_id INTEGER PRIMARY KEY, pos_id INT, ts TEXT, carry_hourly_usd REAL,
      spread_live_apr REAL, note TEXT);
INSERT INTO "accruals" VALUES(1,1,'2026-09-02T09:15:22Z',0.0090311990883775676,4.7958660648241498,'6.60h incremental');
INSERT INTO "accruals" VALUES(2,1,'2026-09-02T13:03:08Z',0.0028660206358651101,2.6453612264563495,'3.80h incremental');
INSERT INTO "accruals" VALUES(3,1,'2026-09-02T15:51:18Z',0.0099252855660827855,12.4077364079481,'2.80h incremental');
INSERT INTO "accruals" VALUES(4,1,'2026-09-02T15:54:14Z',0.00017397960697670772,12.4077364079481,'0.05h incremental');
INSERT INTO "accruals" VALUES(5,2,'2026-09-02T15:54:15Z',6.3928991035555583e-05,46.336020000000019,'0.00h incremental');
INSERT INTO "accruals" VALUES(6,1,'2026-09-02T19:50:19Z',0.00054441920936592128,0.48479303786144873,'3.93h incremental');
INSERT INTO "accruals" VALUES(7,2,'2026-09-02T19:50:20Z',0.063789191830186637,35.504279999999987,'3.93h incremental');
INSERT INTO "accruals" VALUES(8,1,'2026-09-03T04:57:17Z',0.0065522057653385375,2.5184999999999986,'9.12h incremental');
INSERT INTO "accruals" VALUES(9,2,'2026-09-03T04:57:17Z',0.0,0.0,'9.12h incremental');
INSERT INTO "accruals" VALUES(10,1,'2026-09-03T21:02:37Z',0.0076961553155435979,1.6761922469425512,'16.09h incremental');
INSERT INTO "accruals" VALUES(11,2,'2026-09-03T21:02:38Z',0.61747455233068327,84.052199999999985,'16.09h incremental');
INSERT INTO "accruals" VALUES(12,1,'2026-09-04T10:20:36Z',0.10267560799177641,27.05157530059245,'13.30h incremental');
INSERT INTO "accruals" VALUES(13,2,'2026-09-04T10:20:39Z',0.97474776425064513,160.51167,'13.30h incremental');
INSERT INTO "accruals" VALUES(14,1,'2026-09-08T09:44:14Z',-0.059621055962326384,-2.1900000000000004,'95.39h incremental');
INSERT INTO "accruals" VALUES(15,2,'2026-09-08T09:44:16Z',-0.73881767131848175,-16.96155,'95.39h incremental');
CREATE TABLE drift_log(
            did INTEGER PRIMARY KEY, ts TEXT, pos_id INT, pair TEXT,
            hours_held REAL, assumed_rt_pct REAL, entry_cost_pct REAL,
            exit_cost_pct REAL, realized_rt_pct REAL, drift_ratio REAL,
            exit_detail TEXT, live_spread_apr REAL, accrual_usd REAL,
            accrual_hours REAL, accrual_total_usd REAL, kill_flag INT);
INSERT INTO "drift_log" VALUES(1,'2026-09-02T09:15:22Z',1,'INJ bingx->okx',6.5984581675,0.377,0.19304462713184548,0.20293994748731914,0.3959845746191647,1.0503569618545483,'exit slip short 9.3 long 1.0 + fee 10bps',0.047958660648241502,0.0090311990883775676,6.5984581675,0.0090311990883775676,0);
INSERT INTO "drift_log" VALUES(2,'2026-09-02T13:03:08Z',1,'INJ bingx->okx',10.394614993333333,0.377,0.19304462713184548,0.18388822056300105,0.37693284769484658,0.99982187717465942,'exit slip short 7.3 long 1.0 + fee 10bps',0.026453612264563494,0.0028660206358651101,3.79628166,0.011897219724242677,0);
INSERT INTO "drift_log" VALUES(3,'2026-09-02T15:51:18Z',1,'INJ bingx->okx',13.197389275,0.377,0.19304462713184548,0.18406452114364599,0.37710914827549147,1.0002895179721258,'exit slip short 7.4 long 1.1 + fee 10bps',0.124077364079481,0.0099252855660827855,2.8029448305555555,0.021822505290325464,0);
INSERT INTO "drift_log" VALUES(4,'2026-09-02T15:54:15Z',1,'INJ bingx->okx',13.246354837777778,0.377,0.19304462713184548,0.18400934644512418,0.37705397357696968,1.0001431659866569,'exit slip short 7.4 long 1.1 + fee 10bps',0.124077364079481,0.00017397960697670772,0.049132615555555557,0.02199648489730217,0);
INSERT INTO "drift_log" VALUES(5,'2026-09-02T15:54:15Z',2,'UAI aster->binance',0.0030215044444444443,0.243,0.080883482702119453,0.18348863924314024,0.26437212194525972,1.0879511191162952,'exit slip short 4.8 long 4.5 + fee 9bps',0.46336020000000017,6.3928991035555583e-05,0.0030215044444444443,6.3928991035555583e-05,0);
INSERT INTO "drift_log" VALUES(6,'2026-09-02T19:50:20Z',1,'INJ bingx->okx',17.181078737777778,0.377,0.19304462713184548,0.18445500296731343,0.37749963009915893,1.0013252787776099,'exit slip short 7.4 long 1.1 + fee 10bps',0.0048479303786144873,0.00054441920936592128,3.9349676266666664,0.022540904106668092,0);
INSERT INTO "drift_log" VALUES(7,'2026-09-02T19:50:20Z',2,'UAI aster->binance',3.9377454044444442,0.243,0.080883482702119453,0.19574446595266318,0.27662794865478263,1.1383866199785293,'exit slip short 7.1 long 3.5 + fee 9bps',0.35504279999999988,0.063789191830186637,3.9346898488888886,0.063853120821222187,0);
INSERT INTO "drift_log" VALUES(8,'2026-09-03T04:57:17Z',1,'INJ bingx->okx',26.2969457025,0.377,0.19304462713184548,0.24197250578046831,0.43501713291231381,1.1538915992369065,'exit slip short 12.1 long 2.1 + fee 10bps',0.025184999999999985,0.0065522057653385375,9.1161123691666663,0.029093109872006629,0);
INSERT INTO "drift_log" VALUES(9,'2026-09-03T04:57:17Z',2,'UAI aster->binance',13.053612369166666,0.243,0.080883482702119453,0.20432098252167261,0.28520446522379206,1.1736809268468809,'exit slip short 6.6 long 4.9 + fee 9bps',0.0,0.0,9.1158345913888876,0.063853120821222187,0);
INSERT INTO "drift_log" VALUES(10,'2026-09-03T21:02:37Z',1,'INJ bingx->okx',42.385390310277778,0.377,0.19304462713184548,0.11980198039214444,0.31284660752398991,0.82983185019625971,'exit slip short 1.0 long 1.0 + fee 10bps',0.016761922469425511,0.0076961553155435979,16.088445865833332,0.036789265187550227,0);
INSERT INTO "drift_log" VALUES(11,'2026-09-03T21:02:38Z',2,'UAI aster->binance',29.142056976944446,0.243,0.080883482702119453,0.23391774375028057,0.31480122645240005,1.2954782981580248,'exit slip short 11.5 long 2.9 + fee 9bps',0.84052199999999988,0.61747455233068327,16.088445865833332,0.68132767315190546,0);
INSERT INTO "drift_log" VALUES(12,'2026-09-04T10:20:37Z',1,'INJ bingx->okx',55.68544070944445,0.377,0.19304462713184548,0.12195412559191067,0.31499875272375616,0.83554045815319933,'exit slip short 1.0 long 1.2 + fee 10bps',0.27051575300592451,0.10267560799177641,13.299607376111112,0.13946487317932665,0);
INSERT INTO "drift_log" VALUES(13,'2026-09-04T10:20:39Z',2,'UAI aster->binance',42.44210737611111,0.243,0.080883482702119453,0.2775792320328177,0.35846271473493718,1.4751552046705234,'exit slip short 14.0 long 4.7 + fee 9bps',1.6051167000000002,0.97474776425064513,13.299329598333333,1.6560754374025506,0);
INSERT INTO "drift_log" VALUES(14,'2026-09-08T09:44:14Z',1,'INJ bingx->okx',151.0792450952778,0.377,0.19304462713184548,0.12380259875972455,0.31684722589157005,0.84044357000416459,'exit slip short 1.6 long 0.8 + fee 10bps',-0.021900000000000003,-0.059621055962326384,95.393689539722217,0.079843817217000263,0);
CREATE TABLE fills(
      fill_id INTEGER PRIMARY KEY, pos_id INT, ts TEXT, leg TEXT, venue TEXT,
      side TEXT, style TEXT, notional_usd REAL, fill_px REAL, slip_bps REAL,
      fee_bps REAL, simulated INT DEFAULT 1);
INSERT INTO "fills" VALUES(1,1,'2026-09-02T02:39:28Z','short','bingx','sell','taker',250.0,4.833,7.2366380647158826,5.0,1);
INSERT INTO "fills" VALUES(2,1,'2026-09-02T02:39:28Z','long','okx','buy','taker',250.0,4.837,2.0678246484686635,5.0,1);
INSERT INTO "fills" VALUES(3,2,'2026-09-02T15:54:04Z','short','aster','sell','maker',400.0,0.5198,0.0,0.0,1);
INSERT INTO "fills" VALUES(4,2,'2026-09-02T15:54:04Z','long','binance','buy','taker',400.0,0.51901023895,3.0883482702119456,5.0,1);
CREATE TABLE positions(
      pos_id INTEGER PRIMARY KEY, ts_open TEXT, pair TEXT, coin TEXT,
      short_venue TEXT, long_venue TEXT, size_usd REAL, status TEXT,
      reason_open TEXT, ts_close TEXT, reason_close TEXT,
      entry_cost_pct REAL, median_apr REAL);
INSERT INTO "positions" VALUES(1,'2026-09-02T02:39:28Z','INJ bingx->okx','INJ','bingx','okx',250.0,'open','P0 paper basket',NULL,NULL,0.19304462713184548,0.187);
INSERT INTO "positions" VALUES(2,'2026-09-02T15:54:04Z','UAI aster->binance','UAI','aster','binance',400.0,'open','P0 paper basket',NULL,NULL,0.080883482702119453,0.48684);
CREATE TABLE tripwire_log(
      tid INTEGER PRIMARY KEY, ts TEXT, pair TEXT, check_name TEXT,
      passed INT, detail TEXT);
INSERT INTO "tripwire_log" VALUES(1,'2026-09-02T02:39:15Z','XMR dydx->binance','identity-marks',1,'short mid 507.3 vs long mid 508.8 dev 0.30%');
INSERT INTO "tripwire_log" VALUES(2,'2026-09-02T02:39:28Z','XMR dydx->binance','identity-marks',1,'short mid 515.1 vs long mid 508.6 dev 1.27%');
INSERT INTO "tripwire_log" VALUES(3,'2026-09-02T02:39:28Z','XMR dydx->binance','depth-25bps@size',0,'worst slip 148.0bps (sell 148.0/148.0 buy 0.2/0.1)');
INSERT INTO "tripwire_log" VALUES(4,'2026-09-02T02:39:28Z','BTW aster->bitget','identity-marks',1,'short mid 0.4459 vs long mid 0.4463 dev 0.07%');
INSERT INTO "tripwire_log" VALUES(5,'2026-09-02T02:39:28Z','BTW aster->bitget','depth-25bps@size',1,'worst slip 13.6bps (sell 6.0/4.1 buy 13.6/6.2)');
INSERT INTO "tripwire_log" VALUES(6,'2026-09-02T02:39:28Z','BTW aster->bitget','live-spread>=40%median',0,'live -1.8% vs median 86.6%');
INSERT INTO "tripwire_log" VALUES(7,'2026-09-02T02:39:28Z','INJ bingx->okx','identity-marks',1,'short mid 4.837 vs long mid 4.836 dev 0.01%');
INSERT INTO "tripwire_log" VALUES(8,'2026-09-02T02:39:28Z','INJ bingx->okx','depth-25bps@size',1,'worst slip 7.2bps (sell 7.2/7.2 buy 2.1/2.1)');
INSERT INTO "tripwire_log" VALUES(9,'2026-09-02T02:39:28Z','INJ bingx->okx','live-spread>=40%median',1,'live 10.8% vs median 18.7%');
INSERT INTO "tripwire_log" VALUES(10,'2026-09-02T02:39:29Z','LINK nado->okx','identity-marks',1,'short mid 11.19 vs long mid 11.18 dev 0.04%');
INSERT INTO "tripwire_log" VALUES(11,'2026-09-02T02:39:29Z','LINK nado->okx','depth-25bps@size',1,'worst slip 2.1bps (sell 0.4/0.6 buy 2.1/0.4)');
INSERT INTO "tripwire_log" VALUES(12,'2026-09-02T02:39:29Z','LINK nado->okx','live-spread>=40%median',0,'live 5.0% vs median 13.5%');
INSERT INTO "tripwire_log" VALUES(13,'2026-09-02T09:15:59Z','XMR dydx->binance','identity-marks',1,'short mid 524.1 vs long mid 520.4 dev 0.71%');
INSERT INTO "tripwire_log" VALUES(14,'2026-09-02T09:15:59Z','XMR dydx->binance','depth-25bps@size',0,'worst slip 78.7bps (sell 78.7/78.7 buy 0.1/0.1)');
INSERT INTO "tripwire_log" VALUES(15,'2026-09-02T09:15:59Z','BTW aster->bitget','identity-marks',1,'short mid 0.447 vs long mid 0.4477 dev 0.14%');
INSERT INTO "tripwire_log" VALUES(16,'2026-09-02T09:15:59Z','BTW aster->bitget','depth-25bps@size',1,'worst slip 14.6bps (sell 5.6/6.2 buy 9.5/14.6)');
INSERT INTO "tripwire_log" VALUES(17,'2026-09-02T09:15:59Z','BTW aster->bitget','live-spread>=40%median',0,'live 0.0% vs median 86.6%');
INSERT INTO "tripwire_log" VALUES(18,'2026-09-02T09:15:59Z','INJ bingx->okx','duplicate',0,'already open');
INSERT INTO "tripwire_log" VALUES(19,'2026-09-02T09:16:00Z','LINK nado->okx','identity-marks',1,'short mid 11.11 vs long mid 11.11 dev 0.05%');
INSERT INTO "tripwire_log" VALUES(20,'2026-09-02T09:16:00Z','LINK nado->okx','depth-25bps@size',1,'worst slip 1.3bps (sell 0.4/0.4 buy 0.5/1.3)');
INSERT INTO "tripwire_log" VALUES(21,'2026-09-02T09:16:00Z','LINK nado->okx','live-spread>=40%median',0,'live 0.0% vs median 13.5%');
INSERT INTO "tripwire_log" VALUES(22,'2026-09-02T13:02:53Z','XMR dydx->binance','identity-marks',1,'short mid 514.9 vs long mid 509.2 dev 1.13%');
INSERT INTO "tripwire_log" VALUES(23,'2026-09-02T13:02:53Z','XMR dydx->binance','depth-25bps@size',0,'worst slip 127.5bps (sell 127.5/122.4 buy 0.9/0.1)');
INSERT INTO "tripwire_log" VALUES(24,'2026-09-02T13:02:53Z','BTW aster->bitget','identity-marks',1,'short mid 0.4429 vs long mid 0.4431 dev 0.05%');
INSERT INTO "tripwire_log" VALUES(25,'2026-09-02T13:02:53Z','BTW aster->bitget','depth-25bps@size',1,'worst slip 12.7bps (sell 6.1/7.5 buy 12.7/5.0)');
INSERT INTO "tripwire_log" VALUES(26,'2026-09-02T13:02:53Z','BTW aster->bitget','live-spread>=40%median',0,'live 3.3% vs median 86.6%');
INSERT INTO "tripwire_log" VALUES(27,'2026-09-02T13:02:53Z','INJ bingx->okx','duplicate',0,'already open');
INSERT INTO "tripwire_log" VALUES(28,'2026-09-02T13:02:53Z','LINK nado->okx','identity-marks',1,'short mid 11 vs long mid 11 dev 0.04%');
INSERT INTO "tripwire_log" VALUES(29,'2026-09-02T13:02:53Z','LINK nado->okx','depth-25bps@size',1,'worst slip 0.5bps (sell 0.5/0.5 buy 0.5/0.5)');
INSERT INTO "tripwire_log" VALUES(30,'2026-09-02T13:02:53Z','LINK nado->okx','live-spread>=40%median',0,'live -9.2% vs median 13.5%');
INSERT INTO "tripwire_log" VALUES(31,'2026-09-02T15:51:17Z','XMR dydx->binance','identity-marks',1,'short mid 520.6 vs long mid 519.6 dev 0.19%');
INSERT INTO "tripwire_log" VALUES(32,'2026-09-02T15:51:17Z','XMR dydx->binance','depth-25bps@size',0,'worst slip 119.5bps (sell 119.5/27.0 buy 0.1/0.1)');
INSERT INTO "tripwire_log" VALUES(33,'2026-09-02T15:51:17Z','BTW aster->bitget','identity-marks',1,'short mid 0.4488 vs long mid 0.4495 dev 0.15%');
INSERT INTO "tripwire_log" VALUES(34,'2026-09-02T15:51:17Z','BTW aster->bitget','depth-25bps@size',1,'worst slip 11.8bps (sell 3.6/9.0 buy 9.1/11.8)');
INSERT INTO "tripwire_log" VALUES(35,'2026-09-02T15:51:17Z','BTW aster->bitget','live-spread>=40%median',0,'live 22.0% vs median 86.6%');
INSERT INTO "tripwire_log" VALUES(36,'2026-09-02T15:51:17Z','INJ bingx->okx','duplicate',0,'already open');
INSERT INTO "tripwire_log" VALUES(37,'2026-09-02T15:51:17Z','LINK nado->okx','identity-marks',1,'short mid 11.07 vs long mid 11.07 dev 0.03%');
INSERT INTO "tripwire_log" VALUES(38,'2026-09-02T15:51:17Z','LINK nado->okx','depth-25bps@size',1,'worst slip 0.5bps (sell 0.5/0.5 buy 0.5/0.5)');
INSERT INTO "tripwire_log" VALUES(39,'2026-09-02T15:51:17Z','LINK nado->okx','live-spread>=40%median',0,'live 4.1% vs median 13.5%');
INSERT INTO "tripwire_log" VALUES(40,'2026-09-02T15:54:04Z','XMR dydx->binance','identity-marks',1,'short mid 520.6 vs long mid 519.6 dev 0.19%');
INSERT INTO "tripwire_log" VALUES(41,'2026-09-02T15:54:04Z','XMR dydx->binance','depth-25bps@size',0,'worst slip 33.8bps (sell 33.8/25.8 buy 0.4/0.1)');
INSERT INTO "tripwire_log" VALUES(42,'2026-09-02T15:54:04Z','BTW aster->bitget','identity-marks',1,'short mid 0.4503 vs long mid 0.4513 dev 0.23%');
INSERT INTO "tripwire_log" VALUES(43,'2026-09-02T15:54:04Z','BTW aster->bitget','depth-25bps@size',1,'worst slip 13.7bps (sell 1.5/12.6 buy 6.3/13.7)');
INSERT INTO "tripwire_log" VALUES(44,'2026-09-02T15:54:04Z','BTW aster->bitget','live-spread>=40%median',0,'live 22.0% vs median 86.6%');
INSERT INTO "tripwire_log" VALUES(45,'2026-09-02T15:54:04Z','UAI aster->binance','identity-marks',1,'short mid 0.5194 vs long mid 0.5189 dev 0.11%');
INSERT INTO "tripwire_log" VALUES(46,'2026-09-02T15:54:04Z','UAI aster->binance','depth-25bps@size',1,'worst slip 7.7bps (sell 7.7/7.7 buy 3.1/3.6)');
INSERT INTO "tripwire_log" VALUES(47,'2026-09-02T15:54:04Z','UAI aster->binance','live-spread>=40%median',1,'live 46.3% vs median 48.7%');
INSERT INTO "tripwire_log" VALUES(48,'2026-09-02T15:54:04Z','INJ bingx->okx','duplicate',0,'already open');
INSERT INTO "tripwire_log" VALUES(49,'2026-09-02T15:54:04Z','LINK nado->okx','identity-marks',1,'short mid 11.07 vs long mid 11.07 dev 0.03%');
INSERT INTO "tripwire_log" VALUES(50,'2026-09-02T15:54:04Z','LINK nado->okx','depth-25bps@size',1,'worst slip 1.3bps (sell 0.5/0.6 buy 0.5/1.3)');
INSERT INTO "tripwire_log" VALUES(51,'2026-09-02T15:54:04Z','LINK nado->okx','live-spread>=40%median',0,'live 4.1% vs median 13.5%');
INSERT INTO "tripwire_log" VALUES(52,'2026-09-02T19:50:10Z','XMR dydx->binance','identity-marks',1,'short mid 515.8 vs long mid 515.1 dev 0.14%');
INSERT INTO "tripwire_log" VALUES(53,'2026-09-02T19:50:10Z','XMR dydx->binance','depth-25bps@size',0,'worst slip 167.8bps (sell 167.8/164.7 buy 0.1/1.3)');
INSERT INTO "tripwire_log" VALUES(54,'2026-09-02T19:50:10Z','BTW aster->bitget','identity-marks',1,'short mid 0.5169 vs long mid 0.5177 dev 0.16%');
INSERT INTO "tripwire_log" VALUES(55,'2026-09-02T19:50:10Z','BTW aster->bitget','depth-25bps@size',1,'worst slip 8.4bps (sell 6.0/8.2 buy 8.4/6.5)');
INSERT INTO "tripwire_log" VALUES(56,'2026-09-02T19:50:10Z','BTW aster->bitget','live-spread>=40%median',0,'live 0.0% vs median 86.6%');
INSERT INTO "tripwire_log" VALUES(57,'2026-09-02T19:50:10Z','UAI aster->binance','duplicate',0,'already open');
INSERT INTO "tripwire_log" VALUES(58,'2026-09-02T19:50:10Z','INJ bingx->okx','duplicate',0,'already open');
INSERT INTO "tripwire_log" VALUES(59,'2026-09-02T19:50:10Z','LINK nado->okx','identity-marks',1,'short mid 11.08 vs long mid 11.08 dev 0.02%');
INSERT INTO "tripwire_log" VALUES(60,'2026-09-02T19:50:10Z','LINK nado->okx','depth-25bps@size',1,'worst slip 1.0bps (sell 0.5/0.5 buy 1.0/0.5)');
INSERT INTO "tripwire_log" VALUES(61,'2026-09-02T19:50:10Z','LINK nado->okx','live-spread>=40%median',0,'live -0.0% vs median 13.5%');
INSERT INTO "tripwire_log" VALUES(62,'2026-09-03T04:56:20Z','XMR dydx->binance','identity-marks',1,'short mid 509.8 vs long mid 509.4 dev 0.07%');
INSERT INTO "tripwire_log" VALUES(63,'2026-09-03T04:56:20Z','XMR dydx->binance','depth-25bps@size',1,'worst slip 20.6bps (sell 20.6/20.6 buy 0.8/0.1)');
INSERT INTO "tripwire_log" VALUES(64,'2026-09-03T04:56:20Z','XMR dydx->binance','live-spread>=40%median',0,'live -11.0% vs median 97.7%');
INSERT INTO "tripwire_log" VALUES(65,'2026-09-03T04:56:20Z','BTW aster->bitget','identity-marks',1,'short mid 0.4617 vs long mid 0.4614 dev 0.07%');
INSERT INTO "tripwire_log" VALUES(66,'2026-09-03T04:56:20Z','BTW aster->bitget','depth-25bps@size',1,'worst slip 8.2bps (sell 6.4/5.2 buy 7.9/8.2)');
INSERT INTO "tripwire_log" VALUES(67,'2026-09-03T04:56:20Z','BTW aster->bitget','live-spread>=40%median',1,'live 77.6% vs median 86.6%');
INSERT INTO "tripwire_log" VALUES(68,'2026-09-03T04:56:28Z','BTW aster->bitget','m2-chain',0,'v3 chain verdict FAIL');
INSERT INTO "tripwire_log" VALUES(69,'2026-09-03T04:56:28Z','UAI aster->binance','duplicate',0,'already open');
INSERT INTO "tripwire_log" VALUES(70,'2026-09-03T04:56:28Z','INJ bingx->okx','duplicate',0,'already open');
INSERT INTO "tripwire_log" VALUES(71,'2026-09-03T04:56:28Z','LINK nado->okx','identity-marks',1,'short mid 11.24 vs long mid 11.23 dev 0.04%');
INSERT INTO "tripwire_log" VALUES(72,'2026-09-03T04:56:28Z','LINK nado->okx','depth-25bps@size',1,'worst slip 0.4bps (sell 0.4/0.4 buy 0.4/0.4)');
INSERT INTO "tripwire_log" VALUES(73,'2026-09-03T04:56:28Z','LINK nado->okx','live-spread>=40%median',0,'live -0.0% vs median 13.5%');
COMMIT;
