import asyncio
import logging
import signal
from typing import Dict, Optional

from config.settings import settings
from core.interfaces.exchange import BaseExecutionClient
from core.models import ArbitrageOpportunity, PortfolioState
from data.ccxt_ws_client import CcxtWsClient
from data.opportunity_feed import SharpeOpportunityIngestor
from execution.ccxt_adapter import CcxtExecutionAdapter
from execution.hl_adapter import HyperliquidExecutionAdapter
from execution.router import ExecutionRouter
from risk.portfolio_manager import PortfolioManager
from risk.triple_factor_gate import TripleFactorGate

logger = logging.getLogger("YieldHarvester")


class YieldHarvesterEngine:
    def __init__(self):
        self._setup_logging()
        self.settings = settings
        self.is_running = False

        self.clients: Dict[str, BaseExecutionClient] = {}
        self.active_opps: Dict[str, ArbitrageOpportunity] = {}
        
        # Initialize configured adapters
        for exchange_id in settings.active_exchanges:
            if exchange_id == "hyperliquid":
                self.clients["hyperliquid"] = HyperliquidExecutionAdapter(settings)
            else:
                self.clients[exchange_id] = CcxtExecutionAdapter(exchange_id, settings)

        self.portfolio = PortfolioManager(self.clients, settings.GLOBAL_LIQUIDITY_BUFFER_PCT)
        self.router = ExecutionRouter(self.clients)
        self.ingestor = SharpeOpportunityIngestor(settings.SHARPE_API_KEY)
        self.gate = TripleFactorGate(self.router, settings)

    @staticmethod
    def _setup_logging() -> None:
        import os
        import logging.handlers
        level = getattr(logging, settings.LOG_LEVEL.upper(), logging.INFO)
        fmt = logging.Formatter("%(asctime)s %(levelname)-8s %(name)s %(message)s")

        root = logging.getLogger()
        root.setLevel(level)
        root.handlers.clear()

        console = logging.StreamHandler()
        console.setFormatter(fmt)
        console.setLevel(level)
        root.addHandler(console)

        os.makedirs("logs", exist_ok=True)
        file_handler = logging.handlers.RotatingFileHandler(
            "logs/harvester.log", maxBytes=10 * 1024 * 1024, backupCount=5, encoding="utf-8"
        )
        file_handler.setFormatter(fmt)
        file_handler.setLevel(level)
        root.addHandler(file_handler)

    async def run(self):
        self.is_running = True
        self._install_signal_handlers()
        logger.info(f"Starting Multi-Exchange Yield Harvester; dry_run={self.settings.DRY_RUN}")

        tasks = [
            asyncio.create_task(self.harvester_loop()),
            asyncio.create_task(self.monitor_loop()),
        ]
        try:
            await asyncio.gather(*tasks)
        finally:
            for task in tasks:
                task.cancel()

    async def monitor_loop(self):
        while self.is_running:
            try:
                state = await self.portfolio.get_state()
                
                # Check all active opportunities against Triple Factor Gate
                to_remove = []
                for opp_id, opp in self.active_opps.items():
                    # Evaluate gate
                    should_unwind = await self.gate.evaluate_opportunity(opp, state, {})
                    if should_unwind:
                        # Unwind
                        # For now we use the configured allocation per trade as the naive size
                        # In production this would fetch exactly from state.positions_by_exchange
                        naive_size = self.settings.ALLOCATION_PER_TRADE_USD
                        sizes = {f"{leg.exchange}_{leg.symbol}": naive_size for leg in opp.legs}
                        
                        # In MVP we use naive market prices for unwind
                        # For true limit execution we need live L2 book, but router execution allows fallback
                        prices = {f"{leg.exchange}_{leg.symbol}": 0.0 for leg in opp.legs} # 0 triggers market execution if CCXT supports it, or will error.
                        
                        report = await self.gate.execute_unwind(opp, sizes, prices)
                        if report and report.fully_filled:
                            logger.info(f"Successfully unwound {opp.id}")
                            to_remove.append(opp_id)
                
                for r in to_remove:
                    del self.active_opps[r]
                    
            except Exception as e:
                logger.error(f"Monitor loop error: {e}")
            
            await asyncio.sleep(self.settings.POSITION_CHECK_INTERVAL_SECONDS)

    async def harvester_loop(self):
        while self.is_running:
            try:
                state = await self.portfolio.get_state()
                if not self.portfolio.can_allocate(state, self.settings.ALLOCATION_PER_TRADE_USD):
                    logger.info("Skipping harvest: Global Liquidity Buffer reached or insufficient margin.")
                    await asyncio.sleep(10)
                    continue

                # 1. Fetch Opportunities
                logger.debug("Fetching opportunities from Sharpe API...")
                
                # Gather opportunities concurrently
                fetch_tasks = [
                    self.ingestor.fetch_spot_perp(exchanges=self.settings.active_exchanges),
                    self.ingestor.fetch_cross_exchange(exchanges=self.settings.active_exchanges),
                    self.ingestor.fetch_cross_spot(exchanges=self.settings.active_exchanges),
                    self.ingestor.fetch_dated_futures_carry(exchanges=self.settings.active_exchanges),
                    self.ingestor.fetch_calendar_spreads(exchanges=self.settings.active_exchanges)
                ]
                
                results = await asyncio.gather(*fetch_tasks, return_exceptions=True)
                
                all_opps = []
                for res in results:
                    if isinstance(res, list):
                        all_opps.extend(res)
                    else:
                        logger.error(f"Error in opportunity fetch task: {res}")
                
                # Filter opportunities
                valid_opps = [o for o in all_opps if o.net_apr_pct >= self.settings.MIN_NET_PROFIT_MARGIN_PCT * 100]
                valid_opps.sort(key=lambda x: x.net_apr_pct, reverse=True)

                if valid_opps:
                    best_opp = valid_opps[0]
                    if best_opp.id not in self.active_opps:
                        logger.info(f"Found Alpha Opportunity! {best_opp.id} with {best_opp.net_apr_pct:.2f}% Net APR")
                        
                        # Calculate sizing
                        # Future: Leverage logic
                        naive_size = self.settings.ALLOCATION_PER_TRADE_USD
                        sizes = {f"{leg.exchange}_{leg.symbol}": naive_size for leg in best_opp.legs}
                        prices = {f"{leg.exchange}_{leg.symbol}": 0.0 for leg in best_opp.legs}
                        
                        report = await self.router.execute_opportunity(best_opp, sizes, prices)
                        if report.fully_filled:
                            logger.info(f"Successfully Harvested {best_opp.id}")
                            self.active_opps[best_opp.id] = best_opp
                        else:
                            logger.warning(f"Failed to harvest {best_opp.id}: {report.error}")
            
            except Exception as e:
                logger.error(f"Harvester loop error: {e}")
            
            await asyncio.sleep(10)

    def stop(self):
        self.is_running = False

    def _install_signal_handlers(self) -> None:
        try:
            loop = asyncio.get_running_loop()
            for sig in (signal.SIGINT, signal.SIGTERM):
                loop.add_signal_handler(sig, self.stop)
        except NotImplementedError:
            pass

if __name__ == "__main__":
    asyncio.run(YieldHarvesterEngine().run())
